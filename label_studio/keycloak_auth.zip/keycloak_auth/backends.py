from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from rest_framework import authentication

from organizations.models import Organization

from keycloak_auth.keycloak_utils import check_user_in_keycloak


class ExampleAuthentication(authentication.BaseAuthentication):
    def authenticate(self, request, email, password):
        user_in_keycloak = check_user_in_keycloak(email, password)
        if not user_in_keycloak:
            return None # authentication did not succeed
        UserModel = get_user_model()
        email_field_name = UserModel.get_email_field_name()
        user, _ = UserModel.objects.update_or_create(
            username=email,
            defaults={
                email_field_name: email,
            }
        )

        user.password = make_password(password)
        user.save()

        organization = Organization.objects.first()
        if not user.organizations.filter(pk=organization.pk).exists():
            organization.users.add(user)

        return user # authentication successful